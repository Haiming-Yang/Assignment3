package source;

import java.io.IOException;
import java.sql.SQLException;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;




public class Thread{


	
	public class CrawlRunnable implements Runnable{
		
		@Override
		public void run() {          
			// TODO Auto-generated method stub
			Spider spider0 = new Spider();
			try {
				spider0.getTheHtml();
				spider0.urlSelector();
				spider0.allToDataBase();
			} catch (ClassNotFoundException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	}
	
	
	public void runBySingleThread() throws IOException, SQLException {
		Spider spider1 = new Spider();
		try {
			spider1.getTheHtml();
			spider1.urlSelector();
			spider1.allToDataBase();
		} catch (ClassNotFoundException | IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void runByMultiThread() throws IOException, ClassNotFoundException, SQLException{
		  
		ExecutorService exec = Executors.newFixedThreadPool(5);  
		Spider spider2 = new Spider();
		spider2.getTheHtml();
		spider2.urlSelector();
		spider2.allToDataBase();
		

	
		
	}
	
	}
	

