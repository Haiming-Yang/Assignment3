package source;

import java.io.File;

import java.io.IOException;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;



import java.sql.DriverManager;

import java.sql.Connection;
import java.sql.Statement;


import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;



public class Spider {
	
public ArrayList<String> urlsArray = new ArrayList<>();


//public  void  crawl() throws IOException, SQLException, ClassNotFoundException {
//	getTheHtml();
//	urlSelector();
//	
//}
public void getTheHtml() {
	String url = "http://www.shanghaitech.edu.cn/faculty/sist/faculty.html";
	HttpRequest response = HttpRequest.get(url);
	String pageName = "HomePage.html";   
    response.receive(new File(pageName));
}
public  void urlSelector() throws IOException {
	
	File inputHtml = new File("./HomePage.html");
	Document doc = Jsoup.parse(inputHtml,"UTF-8");
	Elements div = doc.select("div.spst");
	Elements urls = div.select("a");
	Iterator<Element> urlsIte =urls.iterator();
	
	while (urlsIte.hasNext()) {
		urlsArray.add("http://www.shanghaitech.edu.cn"+urlsIte.next().attr("href"));
		urlsIte.next();
	}
	/*
	for (int i = 0; i < urlsArray.size(); i++) {
		System.out.println(urlsArray.get(i));
	}
	*/
}
public void getPages() {
	String url;
	for (int i = 0; i < urlsArray.size(); i++) {
		url = urlsArray.get(i);
		HttpRequest response = HttpRequest.get(url);
		String pageName = "Page"+Integer.toString(i)+".html";   
	    response.receive(new File(pageName));
	}
}

private ArrayList<String> parsePages(int i ) throws IOException {
	ArrayList<String > info =  new ArrayList<>();
	ArrayList<String > test =  new ArrayList<>();
	int num = 0;
	//String mailRegex = "^([a-zA-Z0-9]*[-_]?[a-zA-Z0-9]+)*@@([a-zA-Z0-9]*[-_]?[a-zA-Z0-9]+)+[\\.][A-Za-z]{2,3}([\\.][A-Za-z]{2})?$";
	
	File inputHtml = new File("./Page"+Integer.toString(i)+".html");
	Document doc = Jsoup.parse(inputHtml,"UTF-8");
	Elements div1 = doc.select("div.spst_pep");
	Elements div2 = div1.select("div.line");
    Elements td = div1.select("td");
    Iterator<Element> tdIte1 =td.iterator();
    Iterator<Element> tdIte2 =td.iterator();
    while (tdIte2.hasNext()) {
    	test.add(tdIte2.next().text());
   }
    num = test.size();

    info.add(div2.text());
    if (num == 16) {
    while (tdIte1.hasNext()) {
	tdIte1.next();tdIte1.next();tdIte1.next();tdIte1.next();
    	info.add(tdIte1.next().text());
    	tdIte1.next();
    	info.add(tdIte1.next().text());
    	tdIte1.next();tdIte1.next();tdIte1.next();tdIte1.next();tdIte1.next();tdIte1.next();
    	info.add(tdIte1.next().text());
    	tdIte1.next();tdIte1.next();
	}
    }
    
    else if (num == 18) {
    	while (tdIte1.hasNext()) {
    		tdIte1.next();tdIte1.next();tdIte1.next();tdIte1.next();
    	    	info.add(tdIte1.next().text());
    	    	tdIte1.next();
    	    	info.add(tdIte1.next().text());
    	    	
    	    	tdIte1.next();tdIte1.next();tdIte1.next();tdIte1.next();tdIte1.next();tdIte1.next();tdIte1.next();tdIte1.next();
    	    	info.add(tdIte1.next().text());
    	    	info.add(tdIte1.next().text());
    	    	info.set(3, "无");
    	    	tdIte1.next();
    		}
	}
    else if (num == 20) {
    	while (tdIte1.hasNext()) {
    		tdIte1.next();tdIte1.next();tdIte1.next();tdIte1.next();
    	    	info.add(tdIte1.next().text());
    	    	tdIte1.next();
    	    	info.add(tdIte1.next().text());
    	    	tdIte1.next();tdIte1.next();tdIte1.next();tdIte1.next();tdIte1.next();tdIte1.next();tdIte1.next();tdIte1.next();tdIte1.next();tdIte1.next();
    	    	info.add(tdIte1.next().text());
    	    	info.add(tdIte1.next().text());
    	    	info.set(3, "无");
    	    	tdIte1.next();
    		}
    	
	}
   else {
		
	   while (tdIte1.hasNext()) {
    		tdIte1.next();tdIte1.next();tdIte1.next();tdIte1.next();
    	    	info.add(tdIte1.next().text());
    	    	
    	    	tdIte1.next();
    	    	
    	    	info.add(tdIte1.next().text());
    	    	info.add(tdIte1.next().text());
    	    	info.set(3, "无");
    	    	tdIte1.next();tdIte1.next();tdIte1.next();tdIte1.next();tdIte1.next();tdIte1.next();
    	    
    		}
    		
}

    
    //System.out.println(tr.text());
    /*
    for (int i = 0; i < info.size(); i++) {
		System.out.println(info.get(i));
	}
    System.out.println(Integer.toString(info.size()));
    */
    return info;
	
}

private void toDataBase(ArrayList<String> info) throws SQLException, ClassNotFoundException{
	 Connection connection = null;
	 String sql;
	 String url = "jdbc:mysql://127.0.0.1:3306/teachers?"  
               + "user=root&password=Yhm12345.&useUnicode=true&characterEncoding=UTF8";
	
	 
		 Class.forName("com.mysql.jdbc.Driver");
		 connection = DriverManager.getConnection(url);
		 Statement stmt = connection.createStatement();
		 if(info.get(3).length() >255){
			 info.set(3, "太长");
		 }
		 
        sql = "insert into new_table(name,mail,方向,内容) values('" + info.get(0)+"','"+info.get(1)+"','"+info.get(2)+"','"+info.get(3)+"')";
        stmt.executeUpdate(sql);
        

       
           connection.close();
      
}

public void allToDataBase() throws SQLException, IOException, ClassNotFoundException {
	for (int i = 0; i < urlsArray.size(); i++) {
		toDataBase(parsePages(i));
	}
	System.out.println("共处理"+Integer.toString(urlsArray.size())+"个页面");
}


}
