package source;

import java.io.IOException;
import java.sql.SQLException;



public class Main2014302580179 {

	public static void main(String[] args) throws IOException, SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		
		Thread single = new Thread();
		System.out.println("开启单线程");
		long singlebegintime = System.currentTimeMillis();
		single.runBySingleThread();
		long singleendtime = System.currentTimeMillis();
		System.out.println("单线程所用时间："+(singleendtime - singlebegintime)+"ms");
		
	
		Thread multi = new Thread();
		System.out.println("开启多线程");
		long multibegintime = System.currentTimeMillis();
		multi.runByMultiThread();
		long multiendtime = System.currentTimeMillis();
		System.out.println("多线程所用时间："+(multiendtime - multibegintime)+"ms");
   
		//Spider news = new Spider();
		 //news.spider();
		
		
	}

}
